package com.zwx.instalment.app.widget.tablayout.listener;

public interface OnTabSelectListener {
    void onTabSelect(int position);
    void onTabReselect(int position);
}