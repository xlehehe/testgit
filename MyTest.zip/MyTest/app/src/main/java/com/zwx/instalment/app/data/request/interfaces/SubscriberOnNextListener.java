package com.zwx.instalment.app.data.request.interfaces;

/**
 * Created by sam on 16/3/10.
 */
public interface SubscriberOnNextListener<T> {
    void onNext(T t);
}
