package com.zwx.instalment.app.base;

import com.qmuiteam.qmui.arch.QMUIFragmentActivity;

/**
 * author : lizhilong
 * time   : 2019/07/03
 * desc   :
 * version: 1.0
 **/
public abstract class BaseQMUIFragmentActivity extends QMUIFragmentActivity {
}
