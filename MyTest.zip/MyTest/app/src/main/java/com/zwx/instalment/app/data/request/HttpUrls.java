package com.zwx.instalment.app.data.request;

/**
 * author : lizhilong
 * time   : 2019/07/04
 * desc   :
 * version: 1.0
 **/
public class HttpUrls {
    public static final String LOGIN_URL = "api/tokens/login.do";

}
