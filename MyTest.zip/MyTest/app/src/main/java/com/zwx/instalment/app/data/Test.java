package com.zwx.instalment.app.data;

/**
 * author : lizhilong
 * time   : 2019/06/27
 * desc   :
 * version: 1.0
 **/
public class Test {
}
