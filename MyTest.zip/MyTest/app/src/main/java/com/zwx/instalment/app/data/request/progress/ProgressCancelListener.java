package com.zwx.instalment.app.data.request.progress;

/**
 * Created by lizhilong on 18/3/10.
 */
public interface ProgressCancelListener {
    void onCancelProgress();
}
