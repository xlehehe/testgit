package com.zwx.instalment.app.base.mvp;

/**
 * Description: <INetErrView><br>
 * Author:      mxdl<br>
 * Date:        2018/2/26<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
public interface INetErrView {
    //显示网络错误的View
    void showNetWorkErrView();
    //隐藏网络错误的View
    void hideNetWorkErrView();
}
