package com.chanven.lib.cptr.loadmore;

/**
 * Created by Chanven on 2015-11-5.
 */
public interface OnLoadMoreListener {
    public void loadMore();
}
