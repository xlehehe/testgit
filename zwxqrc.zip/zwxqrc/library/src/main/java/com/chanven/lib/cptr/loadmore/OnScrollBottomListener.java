package com.chanven.lib.cptr.loadmore;

public interface OnScrollBottomListener {
	public void onScorllBootom();
}
