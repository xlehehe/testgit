package com.zwx.library.pickerview.wheelview.interfaces;

/**
 * Created by Sai on 2016/7/13.
 */
public interface IPickerViewData {
    String getPickerViewText();
}
