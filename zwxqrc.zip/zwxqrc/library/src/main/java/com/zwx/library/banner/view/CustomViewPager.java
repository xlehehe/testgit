package com.zwx.library.banner.view;

import android.content.Context;
import android.util.AttributeSet;


public class CustomViewPager extends BannerViewPager {
    // do something by yourself.

    public CustomViewPager(Context context) {
        super(context);
    }

    public CustomViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
