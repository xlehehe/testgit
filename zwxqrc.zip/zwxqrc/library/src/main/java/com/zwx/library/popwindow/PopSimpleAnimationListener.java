package com.zwx.library.popwindow;

import android.view.animation.Animation;

/**
 * Created by HMY on 2016/9/10.
 */
public class PopSimpleAnimationListener implements Animation.AnimationListener {
    @Override
    public void onAnimationStart(Animation animation) {
    }

    @Override
    public void onAnimationEnd(Animation animation) {
    }

    @Override
    public void onAnimationRepeat(Animation animation) {
    }
}
