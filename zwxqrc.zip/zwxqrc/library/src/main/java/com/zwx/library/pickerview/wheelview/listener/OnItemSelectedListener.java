package com.zwx.library.pickerview.wheelview.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
