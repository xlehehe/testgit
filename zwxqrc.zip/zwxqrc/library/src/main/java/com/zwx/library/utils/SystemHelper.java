package com.zwx.library.utils;

import android.app.Activity;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         2017/6/2
 */
interface SystemHelper {

    boolean setStatusBarLightMode(Activity activity, boolean isFontColorDark);
}
