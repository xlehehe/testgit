package com.zwx.library.banner.listener;

public interface OnBannerListener {
    public void OnBannerClick(int position);
}
